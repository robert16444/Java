package controller.model;

public enum TaskPriority {
    HIGH,
    MEDIUM,
    LOW;
}
