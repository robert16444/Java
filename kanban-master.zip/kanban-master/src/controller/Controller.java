package controller;

import controller.model.Task;
import controller.model.TaskPriority;
import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.stage.Modality;
import javafx.util.Callback;
import javafx.stage.FileChooser;

import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


public class Controller {
    static final DataFormat TASK_LIST = new DataFormat("TaskList");


    private Main mainApp;
    private Task chosenItem;
    private Task draggedItem;
    private int toBeDeleted = -1;
    private IntegerProperty ind = new SimpleIntegerProperty(-1);

    @FXML
    Button newTaskButton;
    @FXML
    private ListView toDoListView;
    @FXML
    private ListView inProgListView;
    @FXML
    private ListView doneListView;


    @FXML
    public void closeWindow() {
        Platform.exit();
    }

    @FXML
    public void showAuthorInformation(ActionEvent e) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.initOwner(mainApp.getMainWindow());
        alert.setTitle("Author Information");
        alert.setHeaderText(null);
        alert.setContentText("A. Grzanka IS2");
        alert.showAndWait();
    }


    public void setMainApp(Main mainApp) {
        this.mainApp = mainApp;
        toDoListView.setItems(mainApp.getToDoTaskList());
        inProgListView.setItems(mainApp.getInProgTaskList());
        doneListView.setItems(mainApp.getDoneTaskList());


        toDoListView.setOnDragDetected(new DragAndDropHandler.DragDetectedHandler(toDoListView));
        inProgListView.setOnDragDetected(new DragAndDropHandler.DragDetectedHandler(inProgListView));
        doneListView.setOnDragDetected(new DragAndDropHandler.DragDetectedHandler(doneListView));

        toDoListView.setOnDragDone(new DragAndDropHandler.DragDoneHandler(toDoListView));
        inProgListView.setOnDragDone(new DragAndDropHandler.DragDoneHandler(inProgListView));
        doneListView.setOnDragDone(new DragAndDropHandler.DragDoneHandler(doneListView));

        toDoListView.setOnDragOver(new DragAndDropHandler.DragOverHandler(toDoListView));
        inProgListView.setOnDragOver(new DragAndDropHandler.DragOverHandler(inProgListView));
        doneListView.setOnDragOver(new DragAndDropHandler.DragOverHandler(doneListView));

        toDoListView.setOnDragDropped(new DragAndDropHandler.DropHandler(toDoListView));
        inProgListView.setOnDragDropped(new DragAndDropHandler.DropHandler(inProgListView));
        doneListView.setOnDragDropped(new DragAndDropHandler.DropHandler(doneListView));
    }

    @FXML
    public void initialize() {

        toDoListView.setCellFactory(new Callback() {
            @Override
            public Object call(Object param) {
                return new ListCell<Task>() {
                    @Override
                    protected void updateItem(Task paramT, boolean paramBoolean) {

                        super.updateItem(paramT, paramBoolean);


                        if (!isEmpty()) {
                            setText(paramT.getTitle());
                            if (paramT.getPriority() == TaskPriority.LOW) {
                                String style = "-fx-background-color: #c1ffbb;";
                                setStyle(style);
                            } else if (paramT.getPriority() == TaskPriority.MEDIUM) {
                                String style = "-fx-background-color: rgb(255,251,185);";
                                setStyle(style);
                            } else if (paramT.getPriority() == TaskPriority.HIGH) {
                                String style = "-fx-background-color: rgb(255,211,207);";
                                setStyle(style);
                            }

                            Tooltip tooltip = new Tooltip();
                            tooltip.setText(paramT.getDescription());
                            setTooltip(tooltip);


                            ContextMenu contextMenu = new ContextMenu();
                            MenuItem deleteContMenuItem = new MenuItem("Delete");
                            deleteContMenuItem.setOnAction(new EventHandler<ActionEvent>() {
                                @Override
                                public void handle(ActionEvent e) {
                                    mainApp.getToDoTaskList().remove(paramT);
                                }
                            });
                            MenuItem editContMenuItem = new MenuItem("Edit");
                            editContMenuItem.setOnAction(e -> editExistingTask(paramT));
                            contextMenu.getItems().addAll(deleteContMenuItem, editContMenuItem);
                            setContextMenu(contextMenu);

                            getListView().refresh();

                        } else if (isEmpty()) {
                            setStyle(null);
                            setText(null);
                            setContextMenu(null);
                        }
                    }
                };
            }
        });


        inProgListView.setCellFactory(new Callback() {
            @Override
            public Object call(Object param) {
                return new ListCell<Task>() {
                    @Override
                    protected void updateItem(Task paramT, boolean paramBoolean) {

                        super.updateItem(paramT, paramBoolean);


                        if (!isEmpty()) {
                            setText(paramT.getTitle());
                            if (paramT.getPriority() == TaskPriority.LOW) {
                                String style = "-fx-background-color: #c1ffbb;";
                                setStyle(style);
                            } else if (paramT.getPriority() == TaskPriority.MEDIUM) {
                                String style = "-fx-background-color: rgb(255,251,185);";
                                setStyle(style);
                            } else if (paramT.getPriority() == TaskPriority.HIGH) {
                                String style = "-fx-background-color: rgb(255,211,207);";
                                setStyle(style);
                            }

                            Tooltip tooltip = new Tooltip();
                            tooltip.setText(paramT.getDescription());
                            setTooltip(tooltip);


                            ContextMenu contextMenu = new ContextMenu();
                            MenuItem deleteContMenuItem = new MenuItem("Delete");
                            deleteContMenuItem.setOnAction(new EventHandler<ActionEvent>() {
                                @Override
                                public void handle(ActionEvent e) {
                                    mainApp.getInProgTaskList().remove(paramT);
                                }
                            });
                            MenuItem editContMenuItem = new MenuItem("Edit");
                            editContMenuItem.setOnAction(e -> editExistingTask(paramT));
                            contextMenu.getItems().addAll(deleteContMenuItem, editContMenuItem);
                            setContextMenu(contextMenu);

                            getListView().refresh();

                        } else if (isEmpty()) {
                            setStyle(null);
                            setText(null);
                            setContextMenu(null);
                        }
                    }
                };
            }
        });


        doneListView.setCellFactory(new Callback() {
            @Override
            public Object call(Object param) {
                return new ListCell<Task>() {
                    @Override
                    protected void updateItem(Task paramT, boolean paramBoolean) {

                        super.updateItem(paramT, paramBoolean);


                        if (!isEmpty()) {
                            setText(paramT.getTitle());
                            if (paramT.getPriority() == TaskPriority.LOW) {
                                String style = "-fx-background-color: #c1ffbb;";
                                setStyle(style);
                            } else if (paramT.getPriority() == TaskPriority.MEDIUM) {
                                String style = "-fx-background-color: rgb(255,251,185);";
                                setStyle(style);
                            } else if (paramT.getPriority() == TaskPriority.HIGH) {
                                String style = "-fx-background-color: rgb(255,211,207);";
                                setStyle(style);
                            }

                            Tooltip tooltip = new Tooltip();
                            tooltip.setText(paramT.getDescription());
                            setTooltip(tooltip);


                            ContextMenu contextMenu = new ContextMenu();
                            MenuItem deleteContMenuItem = new MenuItem("Delete");
                            deleteContMenuItem.setOnAction(new EventHandler<ActionEvent>() {
                                @Override
                                public void handle(ActionEvent e) {
                                    mainApp.getDoneTaskList().remove(paramT);
                                }
                            });
                            MenuItem editContMenuItem = new MenuItem("Edit");
                            editContMenuItem.setOnAction(e -> editExistingTask(paramT));
                            contextMenu.getItems().addAll(deleteContMenuItem, editContMenuItem);
                            setContextMenu(contextMenu);

                            getListView().refresh();

                        } else if (isEmpty()) {
                            setStyle(null);
                            setText(null);
                            setContextMenu(null);
                        }
                    }
                };
            }
        });

    }

    @FXML
    public void addNewTask() {
        mainApp.showTaskEditDialog(new Task());
    }

    @FXML
    public void editExistingTask(Task task) {
        mainApp.showTaskEditDialog(task);
    }


    @FXML
    public void saveFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save lists");

        FileChooser.ExtensionFilter extFilter =
                new FileChooser.ExtensionFilter("Bin files (*.bin)", "*.bin");
        fileChooser.getExtensionFilters().add(extFilter);

        File file = fileChooser.showSaveDialog(null);

        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(file))) {
            ArrayList<Task> td=new ArrayList<Task>(toDoListView.getItems());
            outputStream.writeObject(td);
            outputStream.writeObject("progress");
            ArrayList<Task>pr=new ArrayList<Task>(inProgListView.getItems());
            outputStream.writeObject(new ArrayList<Task>(pr));
            outputStream.writeObject("done");
            ArrayList<Task> dl=new ArrayList<Task>(doneListView.getItems());
            outputStream.writeObject(new ArrayList<Task>(dl));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @FXML
    public void openFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open lists");

        FileChooser.ExtensionFilter extFilter =
                new FileChooser.ExtensionFilter("Bin files (*.bin)", "*.bin");
        fileChooser.getExtensionFilters().add(extFilter);

        File file = fileChooser.showOpenDialog(null);

        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(file))) {
            List<Task> td=new ArrayList<Task>(toDoListView.getItems());
            ArrayList<Task>pr=new ArrayList<Task>(inProgListView.getItems());
            ArrayList<Task> dl=new ArrayList<Task>(doneListView.getItems());

            ArrayList a1 = (ArrayList<Task>)(inputStream.readObject());

            System.out.print(a1);

            td.removeAll(td);
            toDoListView.refresh();
            td.addAll(td);
            pr.removeAll(pr);
            inProgListView.refresh();
            pr.addAll(pr);
            dl.removeAll(dl);
            doneListView.refresh();
            dl.addAll(dl);

        } catch (FileNotFoundException e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("blad");
            alert.setHeaderText(null);
            alert.setContentText("plik nie isniteje lub ma nie poprawne rozszerzenie");

            alert.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
