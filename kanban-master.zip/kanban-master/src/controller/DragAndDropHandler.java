package controller;


import controller.model.Task;
import javafx.event.EventHandler;
import javafx.scene.control.ListView;
import javafx.scene.input.*;


public class DragAndDropHandler {
    static class DragDetectedHandler implements EventHandler<MouseEvent> {
        private javafx.scene.control.ListView Handled;

        DragDetectedHandler(ListView Handled) {
            this.Handled = Handled;
        }

        public void handle(MouseEvent event) {
            Dragboard db = Handled.startDragAndDrop(TransferMode.MOVE);
            ClipboardContent content = new ClipboardContent();

            if(Handled.getSelectionModel().getSelectedIndex() < 0)
                return;
            content.put(Task.dragAndDropFormat, Handled.getItems().get(Handled.getSelectionModel().getSelectedIndex()));
            db.setContent(content);

            event.consume();
        }
    }

    static class DropHandler implements EventHandler<DragEvent> {

        private ListView Handled;

        DropHandler(ListView Handled) {
            this.Handled = Handled;
        }


        @Override
        public void handle(DragEvent event) {


            Dragboard db = event.getDragboard();
            boolean success = false;
            if (db.hasContent(Task.dragAndDropFormat)) {
                Task t = (Task) db.getContent(Task.dragAndDropFormat);


                Handled.getItems().add(t);


                success = true;

            }
            /* let the source know whether the string was successfully
             * transferred and used */
            event.setDropCompleted(success);
            event.consume();
        }
    }

    static class DragOverHandler implements EventHandler<DragEvent> {

        private ListView Handled;

        DragOverHandler(ListView Handled) {
            this.Handled = Handled;
        }


        @Override
        public void handle(DragEvent event) {
            if (event.getSource() == null)
                return;
            if (event.getGestureSource() != Handled &&
                    event.getDragboard().hasContent(Task.dragAndDropFormat)) {
                event.acceptTransferModes(TransferMode.MOVE);

            }

            event.consume();
        }
    }

    static class DragDoneHandler implements EventHandler<DragEvent> {

        private ListView Handled;

        DragDoneHandler(ListView Handled) {
            this.Handled = Handled;
        }

        @Override
        public void handle(DragEvent event) {
            if (event.getTransferMode() == TransferMode.MOVE) {
                Handled.getItems().remove(Handled.getSelectionModel().getSelectedIndex());
            }
            event.consume();
        }
    }
}

